let num1=10;
let num2=20;

//Arithmetic 
console.log(num1+num2);
console.log(num2-num1);
console.log(num1*num2);
console.log(num2/num1);
console.log(num2%num1);
console.log(++num1)
console.log(--num1)

//assignment opp
 let num=100;
console.log(num);
console.log(num += 50);
console.log(num -= 50);
console.log(num /= 50);

//compare opp
console.log(num==num2);
console.log(num!=num2);
console.log(num1<num2);
console.log(num1>num2);
let num3=10;
console.log(num1>=num3);
console.log(num1<=num2);

//identity opp
console.log('50'===50);
console.log('50'!==50);

//conditional opp
console.log(10>50 && 10<50);
console.log(10<50 && 10<50);
console.log(!num1<num2 );
