//Table of 5
for(let i=5;i < 51;i=i+5){
    console.log(i)
}
 //calculate percentage and give grade
var math=70;
var eng=75;
var hindi=80;
var science=75;
var social=82;
var total=math +eng +hindi+science+social;
console.log('Total marks:='+total)
var percentage=total/500*100;
console.log('Percentage:='+percentage)
if(percentage>=80 && percentage<=100){
    console.log('O grade')
}
else if(percentage>=50 && percentage<59){
    console.log('B grade')   
}
else if(percentage>=60 && percentage<=80){
    console.log('A grade')
}
else{
    console.log('Fail')
}

