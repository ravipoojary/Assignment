var friends=[
    {name:'Anil' ,age:29 ,city:'udupi' ,state:'karnataka'  },
    {name:'Ravi' ,age:28 ,city:'udupi' ,state: 'karnataka' },
    {name:'Reshma' ,age:29 ,city:'udupi' ,state: 'karnataka' },
    {name:'Rajath' ,age:29 ,city:'udupi' ,state: 'karnataka' }
];
//using for loop
console.log('Using for loop')
for(var i=0;i<friends.length;i++){
    console.log(friends[i].name)
    console.log(friends[i].age)
}
//using forEach loop
console.log('Using forEach loop')
friends.forEach(function(friend){
    console.log(friend.name)
    console.log(friend.age)
 
})
